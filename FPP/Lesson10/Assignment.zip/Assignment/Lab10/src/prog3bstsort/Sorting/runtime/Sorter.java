package runtime;

public abstract class Sorter {

	abstract public int[] sort(int[] arr);
}
