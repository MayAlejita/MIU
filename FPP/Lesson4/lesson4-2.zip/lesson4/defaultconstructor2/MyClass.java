package lesson4.defaultconstructor2;

public class MyClass {
	int x = 2;
   
	MyClass(int anInt) {
		x = anInt;
	}
	
	MyClass() {
		//do nothing
	}
}
