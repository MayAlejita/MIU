package pencil_2;

public class Answers {

	public static void main(String[] args) {
		System.out.println("" + (3 * 5 / 9 % 2));
		System.out.println("" + (4 ^ 3 & 5));
		System.out.println("" + (13 >> 2 << 2 ^ 4));
		System.out.println("" + (32 | 16/3 >> 2 & 5));

	}

}
