package prog2closedcurve.closedcurve.good;

abstract public class ClosedCurve {
	abstract double computeArea();

}
