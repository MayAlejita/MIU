package pencil_3;

public class Account {

	double balance;
	Employee emp;

	public double getBalance() {
	   return balance;  
 }
}


