package lesson3.blankfinal;

public class BlankFinal {
	final int blankFinal;
	
	//must initialize when declared because of 'static final'
	//static final int another;
	
	public BlankFinal() {
		blankFinal = 3;
	}

}
