package prog4_2_soln.closedcurve.good;

abstract public class ClosedCurve {
	abstract double computeArea();

}
