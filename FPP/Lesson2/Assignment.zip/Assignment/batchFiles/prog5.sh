echo off
cd /Users/mayrapullupaxi/Documents/MIU/FPP/Workspace/Lab2/bin/
java prog2reverse.Prog5