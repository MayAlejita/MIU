package lesson4.variablesininterface;

public abstract class Abstr {
 abstract void method();
}
