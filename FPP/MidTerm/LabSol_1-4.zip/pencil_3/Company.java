package pencil_3;

public class Company {
	Employee[] employee;

	public Employee[] getAllEmployees() {
		return employee;
	}
}
