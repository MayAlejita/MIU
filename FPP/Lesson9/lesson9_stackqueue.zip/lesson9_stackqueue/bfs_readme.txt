There are two bfs demos here, both
accessible by html files.

bfs - The problem for the students.

bfssolution - The solved problems -- do NOT give this version to the students.