package prog3improvedemployee.employeeinfo;

public enum AccountType {
	 checking,
	 savings,
	 retirement
}
