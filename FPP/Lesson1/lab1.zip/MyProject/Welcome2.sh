cd /Users/mayrapullupaxi/Documents/MIU/FPP/Workspace/MyProject/bin
java mypackage.Welcome2