package lesson2.stringcompareto;

import java.util.Arrays;
import java.util.Date;

public class Test1 {

	public static void main(String[] args) {
		String[] names = {"Steve", "Joe", "Alice", "Tom"};
		//sorts the array in place
		Arrays.sort(names);
		System.out.println(Arrays.toString(names));
				
	}

}
