package prog4_5_soln.closedcurve.good;

abstract public class ClosedCurve {
	abstract double computeArea();

}
