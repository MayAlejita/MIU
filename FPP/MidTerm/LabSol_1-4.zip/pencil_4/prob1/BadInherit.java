package pencil_4.prob1;

public class BadInherit extends SuperClass {

	BadInherit(){
		System.out.println("In BadInherit");
	}
	public static void main(String[] args){
		new BadInherit();
	}
}
