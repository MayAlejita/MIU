package prog2supplement.employeeinfo;

public enum AccountType {
	 checking,
	 savings,
	 retirement
}
