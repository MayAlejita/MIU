package mypackage;

public class Welcome2 {
	public static void main(String[] args) {
		System.out.println(welcome());
	}
	
	public static String welcome() {
		return "Welcome";
	}

}
