package pencil_4.prob1;

class SuperClass {
	SuperClass(){
		new BadInherit();
		System.out.println("In SuperClass");
	}
	
}

