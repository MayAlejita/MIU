package lesson4.abstct;

public class Subsubclass extends Subclass {
	public int num() {
		return 3;
	}
}
