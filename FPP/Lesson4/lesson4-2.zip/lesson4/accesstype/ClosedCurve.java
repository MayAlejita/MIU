package lesson4.accesstype;

abstract public class ClosedCurve {
	abstract double computeArea();

}
