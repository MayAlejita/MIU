package lesson4.defaultconstructor2;

public class Subclass extends MyClass {
	int y = 3;
}
