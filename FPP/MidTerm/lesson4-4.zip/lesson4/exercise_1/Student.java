package lesson4.exercise_1;

public class Student {

}
