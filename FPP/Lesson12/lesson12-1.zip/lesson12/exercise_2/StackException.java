package lesson12.exercise_2;

public class StackException extends Exception {

}
