package prog4_4_soln.closedcurve.good;

public interface Polygon {
	public int getNumberOfSides();
	public double computePerimeter();

}
