package prog1code;

public enum AccountType {
	 CHECKING,
	 SAVINGS,
	 RETIREMENT
}
