package lesson4.variablesininterface;

public interface Animal {
	//implicitly final
	int x = 1;
}
