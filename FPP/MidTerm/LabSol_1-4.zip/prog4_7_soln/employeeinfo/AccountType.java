package prog4_7_soln.employeeinfo;

public enum AccountType {
	CHECKING, 
	SAVINGS, 
	RETIREMENT;
}
