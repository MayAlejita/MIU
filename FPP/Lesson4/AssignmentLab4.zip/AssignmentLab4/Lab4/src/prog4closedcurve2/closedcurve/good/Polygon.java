package prog4closedcurve2.closedcurve.good;

public interface Polygon {
	
	public int getNumberOfSides();
	public double computePerimeter();

}
