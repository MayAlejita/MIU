package lesson4.exercise_5;

//inside firstpackage
public class MySuperClass {
	private String val = "val";
	protected String getVal() {
		return val;
	}
}



