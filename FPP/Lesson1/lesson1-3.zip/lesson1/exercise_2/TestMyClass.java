package lesson1.exercise_2;

import org.junit.Test;

public class TestMyClass {
	@Test
	public void testProduct() {
	
	}
	
	@Test
	public void testConcatenate() {
	
	}
}
