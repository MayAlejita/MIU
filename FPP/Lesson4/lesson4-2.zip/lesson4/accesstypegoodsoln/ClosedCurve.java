package lesson4.accesstypegoodsoln;

abstract public class ClosedCurve {
	abstract double computeArea();

}
