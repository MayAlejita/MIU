package lesson4.inclass.protectedpractice;

//inside... firstpackage
public class MyClass extends MySuperClass {

}


