package pencil_3;

public class Employee {
	public String getStatus() {
		return "";
	}
}
